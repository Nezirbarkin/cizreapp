import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/notification_preferences_model.dart';

class NotificationPreferencesService {
  final _supabase = Supabase.instance.client;

  /// Kullanıcının bildirim tercihlerini getir
  Future<NotificationPreferences?> getUserPreferences(String userId) async {
    try {
      final response = await _supabase
          .from('notification_preferences')
          .select()
          .eq('user_id', userId)
          .maybeSingle();

      if (response == null) {
        // Eğer tercih yoksa, varsayılan tercihleri oluştur
        return await _createDefaultPreferences(userId);
      }

      return NotificationPreferences.fromJson(response);
    } catch (e) {
      throw Exception('Bildirim tercihleri yüklenirken hata: $e');
    }
  }

  /// Varsayılan bildirim tercihlerini oluştur
  Future<NotificationPreferences> _createDefaultPreferences(String userId) async {
    try {
      final data = {
        'user_id': userId,
        'likes_enabled': true,
        'comments_enabled': true,
        'followers_enabled': true,
        'order_updates_enabled': true,
        'order_ready_enabled': true,
        'delivery_enabled': true,
        'promotional_enabled': false,
        'mentions': true,
      };

      final response = await _supabase
          .from('notification_preferences')
          .insert(data)
          .select()
          .single();

      return NotificationPreferences.fromJson(response);
    } catch (e) {
      throw Exception('Varsayılan tercihler oluşturulurken hata: $e');
    }
  }

  /// Bildirim tercihlerini güncelle
  Future<void> updatePreferences({
    required String userId,
    bool? likesEnabled,
    bool? commentsEnabled,
    bool? followersEnabled,
    bool? orderUpdatesEnabled,
    bool? orderReadyEnabled,
    bool? deliveryEnabled,
    bool? promotionalEnabled,
    bool? mentionsEnabled,
  }) async {
    try {
      final Map<String, dynamic> updates = {
        'updated_at': DateTime.now().toIso8601String(),
      };

      if (likesEnabled != null) updates['likes_enabled'] = likesEnabled;
      if (commentsEnabled != null) updates['comments_enabled'] = commentsEnabled;
      if (followersEnabled != null) updates['followers_enabled'] = followersEnabled;
      if (orderUpdatesEnabled != null) updates['order_updates_enabled'] = orderUpdatesEnabled;
      if (orderReadyEnabled != null) updates['order_ready_enabled'] = orderReadyEnabled;
      if (deliveryEnabled != null) updates['delivery_enabled'] = deliveryEnabled;
      if (promotionalEnabled != null) updates['promotional_enabled'] = promotionalEnabled;
      if (mentionsEnabled != null) updates['mentions'] = mentionsEnabled;

      await _supabase
          .from('notification_preferences')
          .update(updates)
          .eq('user_id', userId);
    } catch (e) {
      throw Exception('Tercihler güncellenirken hata: $e');
    }
  }

  /// Belirli bir bildirim türü için tercihi kontrol et
  Future<bool> isNotificationEnabled(String userId, String notificationType) async {
    try {
      final prefs = await getUserPreferences(userId);
      if (prefs == null) return true; // Varsayılan olarak aktif

      switch (notificationType) {
        case 'like':
          return prefs.likesEnabled;
        case 'comment':
          return prefs.commentsEnabled;
        case 'follow':
          return prefs.followersEnabled;
        case 'mention':
          return prefs.mentionsEnabled;
        case 'order_update':
          return prefs.orderUpdatesEnabled;
        case 'order_ready':
          return prefs.orderReadyEnabled;
        case 'delivery':
          return prefs.deliveryEnabled;
        case 'promotional':
          return prefs.promotionalEnabled;
        default:
          return true;
      }
    } catch (e) {
      return true; // Hata durumunda bildirimleri aktif bırak
    }
  }

  /// Tüm bildirimleri aç/kapat
  Future<void> toggleAllNotifications(String userId, bool enabled) async {
    try {
      await updatePreferences(
        userId: userId,
        likesEnabled: enabled,
        commentsEnabled: enabled,
        followersEnabled: enabled,
        mentionsEnabled: enabled,
        orderUpdatesEnabled: enabled,
        orderReadyEnabled: enabled,
        deliveryEnabled: enabled,
        promotionalEnabled: enabled,
      );
    } catch (e) {
      throw Exception('Bildirimler güncellenirken hata: $e');
    }
  }
}
