// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../core/models/group_model.dart';
import '../../../core/models/group_message_model.dart';
import '../services/group_chat_service.dart';
import 'group_settings_screen.dart';
import '../../profile/screens/profile_screen.dart';
import '../../../core/widgets/group_avatar_viewer.dart';

class GroupChatScreen extends StatefulWidget {
  final ChatGroup group;

  const GroupChatScreen({super.key, required this.group});

  @override
  State<GroupChatScreen> createState() => _GroupChatScreenState();
}

class _GroupChatScreenState extends State<GroupChatScreen> {
  final GroupChatService _groupChatService = GroupChatService();
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  List<GroupMessage> _messages = [];
  bool _isLoading = true;
  bool _isSending = false;
  RealtimeChannel? _messagesChannel;
  late ChatGroup _currentGroup;
  int _pendingRequestCount = 0;

  @override
  void initState() {
    super.initState();
    _currentGroup = widget.group;
    _loadMessages();
    _subscribeToMessages();
    _loadPendingRequests();
    // Mesajları okundu olarak işaretle
    _groupChatService.markGroupMessagesAsRead(widget.group.id);
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _messagesChannel?.unsubscribe();
    super.dispose();
  }

  Future<void> _loadMessages() async {
    setState(() => _isLoading = true);
    final messages = await _groupChatService.getGroupMessages(_currentGroup.id);
    if (mounted) {
      setState(() {
        _messages = messages;
        _isLoading = false;
      });
      _scrollToBottom();
    }
  }

  void _subscribeToMessages() {
    _messagesChannel = _groupChatService.subscribeToGroupMessages(
      _currentGroup.id,
      (messages) {
        if (mounted) {
          setState(() => _messages = messages);
          _scrollToBottom();
          // Yeni mesaj geldiğinde okundu olarak işaretle
          _groupChatService.markGroupMessagesAsRead(_currentGroup.id);
        }
      },
    );
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _sendMessage() async {
    final content = _messageController.text.trim();
    if (content.isEmpty || _isSending) return;

    final currentUserId = Supabase.instance.client.auth.currentUser?.id;
    if (currentUserId == null) return;

    setState(() => _isSending = true);
    _messageController.clear();

    // Optimistic: Geçici mesaj ekle
    final tempMessage = GroupMessage.createTemp(
      groupId: _currentGroup.id,
      senderId: currentUserId,
      content: content,
    );

    setState(() {
      _messages.add(tempMessage);
      _scrollToBottom();
    });

    // Mesajı gönder
    final message = await _groupChatService.sendGroupMessage(
      groupId: _currentGroup.id,
      content: content,
    );

    if (mounted) {
      setState(() {
        _isSending = false;
        if (message != null) {
          // Temp mesajı gerçek mesajla değiştir
          final index = _messages.indexWhere((m) => m.id == tempMessage.id);
          if (index != -1) {
            _messages[index] = message;
          }
        } else {
          // Hata durumunda temp mesajı failed yap
          final index = _messages.indexWhere((m) => m.id == tempMessage.id);
          if (index != -1) {
            _messages[index] = tempMessage.copyWith(isFailed: true, isSending: false);
          }
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Mesaj gönderilemedi: ${message == null ? "Sunucu hatası" : "Bilinmeyen hata"}'),
              duration: const Duration(seconds: 3),
              backgroundColor: Colors.red,
            ),
          );
        }
      });
    }
  }

  Future<void> _loadPendingRequests() async {
    if (!_currentGroup.isAdmin) return;
    try {
      final response = await Supabase.instance.client
          .from('group_join_requests')
          .select('id')
          .eq('group_id', _currentGroup.id)
          .eq('status', 'pending');
      if (mounted) {
        setState(() => _pendingRequestCount = (response as List).length);
      }
    } catch (_) {}
  }

  void _showPendingRequests() async {
    try {
      final requests = await Supabase.instance.client
          .from('group_join_requests')
          .select('*')
          .eq('group_id', _currentGroup.id)
          .eq('status', 'pending')
          .order('created_at', ascending: false);

      final list = List<Map<String, dynamic>>.from(requests);

      // Her istek için profil bilgisini ayrı sorgula (FK olmadığı için join yapamıyoruz)
      for (var i = 0; i < list.length; i++) {
        try {
          final profile = await Supabase.instance.client
              .from('profiles')
              .select('full_name, avatar_url, username')
              .eq('id', list[i]['user_id'])
              .maybeSingle();
          list[i]['profiles'] = profile ?? {};
        } catch (_) {
          list[i]['profiles'] = {};
        }
      }

      if (!mounted) return;
      showDialog(
        context: context,
        builder: (ctx) {
          return StatefulBuilder(builder: (ctx, setDState) {
            return AlertDialog(
              title: Text('Katılma İstekleri (${list.length})'),
              content: SizedBox(
                width: double.maxFinite,
                height: 400,
                child: list.isEmpty
                    ? const Center(child: Text('Bekleyen istek yok'))
                    : ListView.builder(
                        itemCount: list.length,
                        itemBuilder: (_, i) {
                          final req = list[i];
                          final p = req['profiles'] as Map<String, dynamic>?;
                          final name = p?['full_name'] ?? p?['username'] ?? 'Bilinmeyen';
                          final avatar = p?['avatar_url'] as String?;
                          final msg = req['message'] as String?;
                          return Card(
                            child: ListTile(
                              leading: CircleAvatar(
                                backgroundImage: avatar != null ? NetworkImage(avatar) : null,
                                child: avatar == null ? const Icon(Icons.person) : null,
                              ),
                              title: Text(name),
                              subtitle: msg != null && msg.isNotEmpty ? Text(msg, maxLines: 2, overflow: TextOverflow.ellipsis) : null,
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                    icon: const Icon(Icons.close, color: Colors.red),
                                    onPressed: () async {
                                      try {
                                        final success = await _groupChatService.rejectJoinRequest(req['id']);
                                        if (success) {
                                          setDState(() => list.removeAt(i));
                                          _loadPendingRequests();
                                          if (mounted) {
                                            ScaffoldMessenger.of(context).showSnackBar(
                                              const SnackBar(content: Text('İstek reddedildi'), backgroundColor: Colors.green),
                                            );
                                          }
                                        } else {
                                          if (mounted) {
                                            ScaffoldMessenger.of(context).showSnackBar(
                                              const SnackBar(content: Text('İstek reddedilemedi'), backgroundColor: Colors.red),
                                            );
                                          }
                                        }
                                      } catch (e) {
                                        if (mounted) {
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            SnackBar(content: Text('Hata: $e'), backgroundColor: Colors.red),
                                          );
                                        }
                                      }
                                    },
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.check, color: Colors.green),
                                    onPressed: () async {
                                      try {
                                        final success = await _groupChatService.approveJoinRequest(req['id']);
                                        if (success) {
                                          setDState(() => list.removeAt(i));
                                          _loadPendingRequests();
                                          if (mounted) {
                                            ScaffoldMessenger.of(context).showSnackBar(
                                              const SnackBar(content: Text('İstek onaylandı'), backgroundColor: Colors.green),
                                            );
                                          }
                                        } else {
                                          if (mounted) {
                                            ScaffoldMessenger.of(context).showSnackBar(
                                              const SnackBar(content: Text('İstek onaylanamadı'), backgroundColor: Colors.red),
                                            );
                                          }
                                        }
                                      } catch (e) {
                                        if (mounted) {
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            SnackBar(content: Text('Hata: $e'), backgroundColor: Colors.red),
                                          );
                                        }
                                      }
                                    },
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
              actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Kapat'))],
            );
          });
        },
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('İstekler yüklenemedi: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  void _showSenderProfile(String senderId) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileScreen(userId: senderId)));
  }

  void _openGroupSettings() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => GroupSettingsScreen(group: _currentGroup),
      ),
    );

    if (result is ChatGroup && mounted) {
      setState(() => _currentGroup = result);
    }
    
    // Gruptan çıkarıldıysa veya grup silindiyse geri dön
    if (result == false && mounted) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentUserId = Supabase.instance.client.auth.currentUser?.id;
    final theme = Theme.of(context);
    final isDarkMode = theme.brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDarkMode ? Colors.grey[900] : Colors.grey[100],
      appBar: AppBar(
        backgroundColor: theme.primaryColor,
        foregroundColor: Colors.white,
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 2,
        title: InkWell(
          onTap: _openGroupSettings,
          child: Row(
            children: [
              GestureDetector(
                onTap: () {
                  if (_currentGroup.avatarUrl != null) {
                    showGroupAvatarFullscreen(
                      context: context,
                      imageUrl: _currentGroup.avatarUrl!,
                      title: _currentGroup.name,
                    );
                  }
                },
                child: CircleAvatar(
                  radius: 18,
                  backgroundColor: Colors.white.withOpacity(0.2),
                  backgroundImage: _currentGroup.avatarUrl != null
                      ? NetworkImage(_currentGroup.avatarUrl!)
                      : null,
                  child: _currentGroup.avatarUrl == null
                      ? Icon(
                          _currentGroup.isPrivate ? Icons.lock : Icons.groups,
                          size: 20,
                          color: Colors.white,
                        )
                      : null,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _currentGroup.name,
                      style: const TextStyle(fontSize: 16),
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      '${_currentGroup.memberCount} üye',
                      style: TextStyle(
                        fontSize: 11,
                        color: Colors.white.withOpacity(0.8),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          // Katılma istekleri (admin ise)
          if (_currentGroup.isAdmin && _pendingRequestCount > 0)
            Stack(
              children: [
                IconButton(
                  icon: const Icon(Icons.person_add),
                  onPressed: _showPendingRequests,
                  tooltip: 'Katılma İstekleri',
                ),
                Positioned(
                  right: 4,
                  top: 4,
                  child: IgnorePointer(
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                      child: Text('$_pendingRequestCount', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ),
              ],
            )
          else if (_currentGroup.isAdmin)
            IconButton(
              icon: const Icon(Icons.person_add_outlined),
              onPressed: _showPendingRequests,
              tooltip: 'Katılma İstekleri',
            ),
          IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: _openGroupSettings,
          ),
        ],
      ),
      body: Column(
        children: [
          // Mesajlar listesi
          Expanded(
            child: Container(
              color: isDarkMode ? const Color(0xFF0B141A) : const Color(0xFFECE5DD),
              child: _isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : _messages.isEmpty
                      ? _buildEmptyState()
                      : ListView.builder(
                          controller: _scrollController,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 12,
                          ),
                          itemCount: _messages.length,
                        itemBuilder: (context, index) {
                          final message = _messages[index];
                          final isMe = message.senderId == currentUserId;
                          final showDate = index == 0 ||
                              !_isSameDay(
                                _messages[index - 1].createdAt,
                                message.createdAt,
                              );
                          final showSender = !isMe &&
                              (index == 0 ||
                                  _messages[index - 1].senderId != message.senderId);

                          return Column(
                            children: [
                              if (showDate) _buildDateDivider(message.createdAt),
                              _buildMessageBubble(message, isMe, showSender),
                            ],
                          );
                        },
                      ),
            ),
          ),

          // Mesaj gönderme alanı
          Container(
            decoration: BoxDecoration(
              color: isDarkMode ? Colors.grey[850] : Colors.white,
              boxShadow: [
                BoxShadow(
                  offset: const Offset(0, -2),
                  blurRadius: 8,
                  color: Colors.black.withOpacity(0.05),
                ),
              ],
            ),
            padding: EdgeInsets.only(
              left: 16,
              right: 8,
              top: 8,
              bottom: MediaQuery.of(context).padding.bottom + 8,
            ),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: isDarkMode ? Colors.grey[800] : Colors.grey[100],
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: TextField(
                      controller: _messageController,
                      decoration: InputDecoration(
                        hintText: 'Mesaj yazın...',
                        border: InputBorder.none,
                        hintStyle: TextStyle(
                          color: isDarkMode ? Colors.grey[500] : Colors.grey[600],
                        ),
                      ),
                      style: TextStyle(
                        color: isDarkMode ? Colors.white : Colors.black87,
                      ),
                      maxLines: null,
                      textCapitalization: TextCapitalization.sentences,
                      onSubmitted: (_) => _sendMessage(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  decoration: const BoxDecoration(
                    color: Colors.deepPurple,
                    shape: BoxShape.circle,
                  ),
                  child: IconButton(
                    icon: _isSending
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.send, color: Colors.white),
                    onPressed: _isSending ? null : _sendMessage,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.groups_outlined,
            size: 80,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'Henüz mesaj yok',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w500,
              color: isDarkMode ? Colors.grey[400] : Colors.grey[700],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'İlk mesajı göndererek sohbeti başlatın',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: isDarkMode ? Colors.grey[500] : Colors.grey[600],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDateDivider(DateTime date) {
    const turkeyOffset = Duration(hours: 3);
    final turkeyDate = date.toUtc().add(turkeyOffset);
    final now = DateTime.now().toUtc().add(turkeyOffset);
    final today = DateTime(now.year, now.month, now.day);
    final messageDate = DateTime(turkeyDate.year, turkeyDate.month, turkeyDate.day);

    String dateText;
    if (messageDate == today) {
      dateText = 'Bugün';
    } else if (messageDate == today.subtract(const Duration(days: 1))) {
      dateText = 'Dün';
    } else {
      final day = turkeyDate.day.toString().padLeft(2, '0');
      final month = turkeyDate.month.toString().padLeft(2, '0');
      dateText = '$day.$month.${turkeyDate.year}';
    }

    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: Theme.of(context).brightness == Brightness.dark
              ? const Color(0xFF182229)
              : const Color(0xFFE1F2FB),
          borderRadius: BorderRadius.circular(8),
          boxShadow: [
            BoxShadow(
              offset: const Offset(0, 1),
              blurRadius: 0.5,
              color: Colors.black.withOpacity(0.06),
            ),
          ],
        ),
        child: Text(
          dateText,
          style: TextStyle(
            fontSize: 12.5,
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.white70
                : const Color(0xFF667781),
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }

  Widget _buildMessageBubble(GroupMessage message, bool isMe, bool showSender) {
    const turkeyOffset = Duration(hours: 3);
    final turkeyTime = message.createdAt.toUtc().add(turkeyOffset);
    final timeString =
        '${turkeyTime.hour.toString().padLeft(2, '0')}:${turkeyTime.minute.toString().padLeft(2, '0')}';

    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    
    // WhatsApp renkleri
    final Color bubbleColor = isMe
        ? (isDarkMode ? const Color(0xFF005C4B) : const Color(0xFFDCF8C6)) // Gönderen: yeşil
        : (isDarkMode ? const Color(0xFF1F2C33) : Colors.white); // Alıcı: beyaz
    
    final Color textColor = isMe
        ? (isDarkMode ? Colors.white : Colors.black87)
        : (isDarkMode ? Colors.white : Colors.black87);

    return Padding(
      padding: EdgeInsets.only(
        left: isMe ? 64 : 8,
        right: isMe ? 8 : 64,
        bottom: 2,
        top: showSender && !isMe ? 6 : 2,
      ),
      child: Row(
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Profil resmi (sol tarafta, sadece grup mesajlarında ve gönderen değiştiğinde)
          if (!isMe && showSender)
            GestureDetector(
              onTap: () => _showSenderProfile(message.senderId),
              child: CircleAvatar(
                radius: 16,
                backgroundImage: message.senderAvatarUrl != null
                    ? NetworkImage(message.senderAvatarUrl!)
                    : null,
                backgroundColor: _getSenderColor(message.senderId).withOpacity(0.2),
                child: message.senderAvatarUrl == null
                    ? Text(
                        (message.senderName ?? 'U')[0].toUpperCase(),
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: _getSenderColor(message.senderId),
                        ),
                      )
                    : null,
              ),
            )
          else if (!isMe)
            const SizedBox(width: 32), // Boşluk bırak (profil resmi gösterilmediğinde)

          if (!isMe) const SizedBox(width: 6),

          // Mesaj baloncuğu
          Flexible(
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: bubbleColor,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(8),
                  topRight: const Radius.circular(8),
                  bottomLeft: isMe ? const Radius.circular(8) : const Radius.circular(0),
                  bottomRight: isMe ? const Radius.circular(0) : const Radius.circular(8),
                ),
                boxShadow: [
                  BoxShadow(
                    offset: const Offset(0, 1),
                    blurRadius: 0.5,
                    spreadRadius: 0,
                    color: Colors.black.withOpacity(0.13),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Gönderen adı (sadece başkalarının mesajlarında, mesaj içinde)
                  if (showSender && !isMe)
                    GestureDetector(
                      onTap: () => _showSenderProfile(message.senderId),
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 2),
                        child: Text(
                          message.senderName ?? 'Bilinmeyen',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: _getSenderColor(message.senderId),
                          ),
                        ),
                      ),
                    ),
                  
                  // Mesaj metni ve saat + durum (aynı satırda, sağda)
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Expanded(
                        child: Text(
                          message.content,
                          style: TextStyle(
                            fontSize: 14.5,
                            color: textColor,
                            height: 1.3,
                          ),
                        ),
                      ),
                      const SizedBox(width: 4),
                      // Saat ve durum simgesi
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            timeString,
                            style: TextStyle(
                              fontSize: 11,
                              color: (isMe && !isDarkMode)
                                  ? Colors.black.withOpacity(0.45)
                                  : (isDarkMode ? Colors.white60 : Colors.black.withOpacity(0.45)),
                            ),
                          ),
                          if (isMe) ...[
                            const SizedBox(width: 3),
                            _buildMessageStatusIcon(message.messageStatus, isDarkMode),
                          ],
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          
          if (isMe) const SizedBox(width: 6),
        ],
      ),
    );
  }

  Widget _buildMessageStatusIcon(String status, bool isDarkMode) {
    final Color tickColor = isDarkMode
        ? Colors.white60
        : const Color(0xFF53BDEB); // WhatsApp mavi tik rengi
    
    switch (status) {
      case 'failed':
        return const Icon(Icons.error_outline, size: 14, color: Colors.red);
      case 'sending':
        return SizedBox(
          width: 14,
          height: 14,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            valueColor: AlwaysStoppedAnimation<Color>(isDarkMode ? Colors.white60 : Colors.grey),
          ),
        );
      case 'sent':
        return Icon(Icons.done_all, size: 16, color: tickColor);
      default:
        return Icon(Icons.done, size: 16, color: isDarkMode ? Colors.white60 : Colors.grey);
    }
  }

  bool _isSameDay(DateTime date1, DateTime date2) {
    return date1.year == date2.year &&
        date1.month == date2.month &&
        date1.day == date2.day;
  }

  Color _getSenderColor(String senderId) {
    // Her gönderene farklı renk ata
    final colors = [
      Colors.blue[700]!,
      Colors.green[700]!,
      Colors.orange[700]!,
      Colors.purple[700]!,
      Colors.red[700]!,
      Colors.teal[700]!,
      Colors.pink[700]!,
      Colors.indigo[700]!,
    ];
    
    int hash = 0;
    for (int i = 0; i < senderId.length; i++) {
      hash = senderId.codeUnitAt(i) + ((hash << 5) - hash);
    }
    return colors[hash.abs() % colors.length];
  }
}
